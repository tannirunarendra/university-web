package com.cts.University.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.University.model.Complains;

@Repository
public interface ComplainsRepository extends JpaRepository<Complains, String> {

	
	
}

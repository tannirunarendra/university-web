package com.cts.University.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

@Entity
public class IdeaSubmission {

	@Id
	@NotEmpty(message = "IdeaTopic must be entered")
	private String ideaTopic ;
	@NotEmpty(message = "IdeaDescription must be entered")
	private String ideaDescription ;
	public String getIdeaTopic() {
		return ideaTopic;
	}
	public void setIdeaTopic(String ideaTopic) {
		this.ideaTopic = ideaTopic;
	}
	public String getIdeaDescription() {
		return ideaDescription;
	}
	public void setIdeaDescription(String ideaDescription) {
		this.ideaDescription = ideaDescription;
	}
	
	
	
}

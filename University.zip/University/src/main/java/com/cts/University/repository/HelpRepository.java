package com.cts.University.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.cts.University.model.Help;

@Repository
public interface HelpRepository extends JpaRepository<Help, String>{

	//List<Help> findRequestbyId(String eventId);
	@Query("select a from Help a")
	List<Help> findRequestbyId();
	
	@Query("select a from Help a where requestId=?1")
	Help findRequestbyId1(int requestId);
	
	@Query("select a from Help a where userId=?1")
	List<Help> findRequestbyId2(String userId);
}
